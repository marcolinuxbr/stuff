The following files are made available at no charge for individual, personal use at no charge.  These are 
copyrighted materials and may not be used for commercial purposes without the specific written 
permission of Russell Bik Design.

Sensor.zip contains the following files:

1.	Readme.txt		This initial page of instructions
2.	Manual.pdf		The full instruction manual that shipped with the sensor.
3.	FAQ.pdf			The list of Frequently Asked Questions from the company web site.
4.	Bill of Material.pdf	The component list with sourcing information.
5.	Sensor.sch		The CIRCAD schematic data file
6.	Sensor.pcb		The CIRCAD pcb data file

If you do not have the Adobe Acrobat reader for pdf files, it can be obtained a no charge from:
http://www.adobe.com

7.	setupcc.exe		The CIRCAD demo program setup file.

The CIRCAD demo program is windows based and will install automatically on Win95B (OSR2), Win98, 
NT and 2000.  If you have Win95 prior to the "B" version, will also need to install the Microsoft directx.exe 
file available at: http://databank.home.att.net/pub/directx.exe

After installation of CIRCAD, open either the sensor.sch or sensor.pcb files.  These files can be viewed 
directly within the program or printed out using the plotter function.  When using the plotter function, it will 
be necessary to adjust margins, and select the individual layers to print.  Although the program refers to 
"plotter" output, the printer attached to your computer will suffice for the sensor drawing sizes.  
Appropriate positive, negative or mirror images can be printed onto 3M Transparency Film for exposing 
photosensitized pcb boards.  Photographic direct contact fabrication is the only method of reliably 
producing the fine traces used in this design.  The demo program will not output Gerber files, but they are 
available from Russell Bik Design for commercial purposes.

If you have additional questions regarding the operation of the CIRCAD program, it includes a very 
extensive built-in help system.



